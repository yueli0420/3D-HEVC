﻿Executable files for the Unsupervised learning based tunable early CU size decision for depth map intra coding in 3D-HEVC method, which is provided by Yue Li (liyue AT usc Dot edu Dot cn).

TAppEncoder_liyue_1, TAppEncoder_liyue_1.5, TAppEncoder_liyue_2, and TAppEncoder_liyue_3 respectively correspond to executable files in different Th in Table 2. These executable files are used to encode the  videos of 3D-HEVC in the AI coding configuration.



